/**
 * 
 */
/**
 * 
 */
module MVCTV {
	requires java.desktop;
	requires java.sql;
}